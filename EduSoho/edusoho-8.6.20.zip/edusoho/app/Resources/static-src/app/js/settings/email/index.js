import Email from './email';
new Email();
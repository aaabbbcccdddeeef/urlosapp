import Order from './order';

new Order({
  element: '#order-create-form'
});
import Manage from './manage';

new Manage();

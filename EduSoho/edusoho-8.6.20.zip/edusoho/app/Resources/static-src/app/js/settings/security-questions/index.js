import SecurityQuestion from './security-questions';

new SecurityQuestion({
  element: '#settings-security-questions-form',
  saveBtn: '#password-save-btn'
});

import OrderSms from './order-sms';

new OrderSms({
  element: '#js-sms-modal-form',
  formSubmit: '#form-submit'
});
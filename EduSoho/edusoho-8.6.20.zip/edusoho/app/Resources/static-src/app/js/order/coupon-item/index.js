import Coupon from './coupon';

new Coupon({
  form: '#order-create-form'
});
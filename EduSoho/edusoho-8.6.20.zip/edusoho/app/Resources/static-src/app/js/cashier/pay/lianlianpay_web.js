import AlipayLegacyExpress from './alipay_legacy_express';

export default class LianlianpayWeb extends AlipayLegacyExpress {

}

import AlipayLegacyWap from './alipay_legacy_wap';

export default class LianlianpayWap extends AlipayLegacyWap {}
import CashierForm from './form';

new CashierForm({
  element: '#cashier-form'
});